# 作者: 张浩然
# 2022年06月09日12时21分09秒
def send():
    return "this is send!"