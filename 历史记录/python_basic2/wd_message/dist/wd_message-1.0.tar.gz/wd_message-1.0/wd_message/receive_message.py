# 作者: 张浩然
# 2022年06月09日12时21分24秒
def receive():
    return "this is receive!"
